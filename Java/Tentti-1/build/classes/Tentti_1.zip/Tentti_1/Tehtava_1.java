package Tentti_1;

public class Tehtava_1 {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.print(i);
            for (int j = 0; j < 10; j++) {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
